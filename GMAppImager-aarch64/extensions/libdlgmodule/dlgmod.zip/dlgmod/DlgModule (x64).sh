cd "${0%/*}"

mkdir "DlgModule (x64)"
clang++ "/opt/local/lib/libSDL2.a" "/opt/local/lib/libiconv.a" "lib/ImGuiFileDialog/ImGuiFileDialog.cpp"  "imgui.cpp" "imgui_impl_sdlrenderer.cpp" "imgui_impl_sdl.cpp" "imgui_draw.cpp" "imgui_tables.cpp" "imgui_widgets.cpp" "dlgmodule.mm" "setpolicy.mm" "main.cpp" "config.cpp" -o "DlgModule (x64)/dlgmod" -I/opt/local/include/SDL2 -std=c++17 -I. -ObjC++ -Wl,-framework,CoreAudio -Wl,-framework,AudioToolbox -Wl,-weak_framework,CoreHaptics -Wl,-weak_framework,GameController -Wl,-framework,ForceFeedback -lobjc -Wl,-framework,CoreVideo -Wl,-framework,Cocoa -Wl,-framework,Carbon -Wl,-framework,IOKit -Wl,-weak_framework,QuartzCore -Wl,-weak_framework,Metal -fPIC -arch arm64 -arch x86_64
