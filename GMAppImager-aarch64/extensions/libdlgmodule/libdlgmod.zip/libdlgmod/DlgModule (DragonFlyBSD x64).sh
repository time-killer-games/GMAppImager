cd "${0%/*}"

mkdir "DlgModule (x64)"
mkdir "DlgModule (x64)/DragonFlyBSD"
g++ "libSDL2.a" "lib/ImGuiFileDialog/ImGuiFileDialog.cpp"  "imgui.cpp" "imgui_impl_sdlrenderer.cpp" "imgui_impl_sdl.cpp" "imgui_draw.cpp" "imgui_tables.cpp" "imgui_widgets.cpp" "DlgModule/Universal/dlgmodule.cpp" "DlgModule/xlib/dlgmodule.cpp" "DlgModule/xlib/lodepng.cpp" -o "DlgModule (x64)/DragonFlyBSD/libdlgmod.so" -std=c++17 -I/usr/local/include -L/usr/local/lib -shared -I. -lX11 -lkvm -lutil -lc -lpthread -fPIC -m64
