cd "${0%/*}"

mkdir "DlgModule (x86)"
mkdir "DlgModule (x86)/FreeBSD"
clang++ "libSDL2.a" "lib/ImGuiFileDialog/ImGuiFileDialog.cpp"  "imgui.cpp" "imgui_impl_sdlrenderer.cpp" "imgui_impl_sdl.cpp" "imgui_draw.cpp" "imgui_tables.cpp" "imgui_widgets.cpp" "DlgModule/Universal/dlgmodule.cpp" "DlgModule/xlib/dlgmodule.cpp" "DlgModule/xlib/lodepng.cpp" -o "DlgModule (x86)/FreeBSD/libdlgmod.so" -std=c++17 -I/usr/local/include -L/usr/local/lib -shared -I. -lX11 -lprocstat -lutil -lc -lpthread -fPIC -m32
