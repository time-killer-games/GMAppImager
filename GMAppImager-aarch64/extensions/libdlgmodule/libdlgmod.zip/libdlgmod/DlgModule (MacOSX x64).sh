cd "${0%/*}"

mkdir "DlgModule (x64)"
mkdir "DlgModule (x64)/MacOSX"
clang++ "/opt/local/lib/libSDL2.a" "/opt/local/lib/libiconv.a" "lib/ImGuiFileDialog/ImGuiFileDialog.cpp"  "imgui.cpp" "imgui_impl_sdlrenderer.cpp" "imgui_impl_sdl.cpp" "imgui_draw.cpp" "imgui_tables.cpp" "imgui_widgets.cpp" "DlgModule/Universal/dlgmodule.cpp" "DlgModule/MacOSX/dlgmodule.mm" "DlgModule/MacOSX/config.cpp" -o "DlgModule (x64)/MacOSX/libdlgmod.dylib" -I/opt/local/include/SDL2 -std=c++17 -I. -ObjC++ -Wl,-framework,CoreAudio -Wl,-framework,AudioToolbox -Wl,-weak_framework,CoreHaptics -Wl,-weak_framework,GameController -Wl,-framework,ForceFeedback -lobjc -Wl,-framework,CoreVideo -Wl,-framework,Cocoa -Wl,-framework,Carbon -Wl,-framework,IOKit -Wl,-weak_framework,QuartzCore -Wl,-weak_framework,Metal -shared -fPIC -arch arm64 -arch x86_64
