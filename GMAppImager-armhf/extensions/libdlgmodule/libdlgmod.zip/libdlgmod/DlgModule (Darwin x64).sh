cd "${0%/*}"

mkdir "DlgModule (x64)"
mkdir "DlgModule (x64)/Darwin"
export SDKROOT=`xcrun --show-sdk-path`
/opt/local/bin/g++-mp-* "libSDL2.a" "lib/ImGuiFileDialog/ImGuiFileDialog.cpp"  "imgui.cpp" "imgui_impl_sdlrenderer.cpp" "imgui_impl_sdl.cpp" "imgui_draw.cpp" "imgui_tables.cpp" "imgui_widgets.cpp" "DlgModule/Universal/dlgmodule.cpp" "DlgModule/xlib/dlgmodule.cpp" "DlgModule/xlib/lodepng/lodepng.cpp" -o "DlgModule (x64)/Darwin/libdlgmod.dylib" `sdl2-config --cflags --static-libs` -I/opt/local/include -L/opt/local/lib -std=c++17 -shared -I.  -static-libgcc -static-libstdc++ -I/opt/X11/include -L/opt/X11/lib -lX11 -fPIC -m64
