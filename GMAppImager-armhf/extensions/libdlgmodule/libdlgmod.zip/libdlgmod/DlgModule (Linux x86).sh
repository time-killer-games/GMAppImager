cd "${0%/*}"

mkdir "DlgModule (x86)"
mkdir "DlgModule (x86)/Linux"
g++ "libSDL2.a" "lib/ImGuiFileDialog/ImGuiFileDialog.cpp"  "imgui.cpp" "imgui_impl_sdlrenderer.cpp" "imgui_impl_sdl.cpp" "imgui_draw.cpp" "imgui_tables.cpp" "imgui_widgets.cpp" "DlgModule/Universal/dlgmodule.cpp" "DlgModule/xlib/dlgmodule.cpp" "DlgModule/xlib/lodepng.cpp" -o "DlgModule (x86)/Linux/libdlgmod.so" -std=c++17 -shared -I. -static-libgcc -static-libstdc++ -lX11 -lprocps -lpthread -fPIC -m32
