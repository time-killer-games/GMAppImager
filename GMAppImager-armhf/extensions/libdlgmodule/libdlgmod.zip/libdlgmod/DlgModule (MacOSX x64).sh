cd "${0%/*}"

mkdir "DlgModule (x64)"
mkdir "DlgModule (x64)/MacOSX"
clang++ "libSDL2.a" "lib/ImGuiFileDialog/ImGuiFileDialog.cpp"  "imgui.cpp" "imgui_impl_sdlrenderer.cpp" "imgui_impl_sdl.cpp" "imgui_draw.cpp" "imgui_tables.cpp" "imgui_widgets.cpp" "DlgModule/Universal/dlgmodule.cpp" "DlgModule/MacOSX/dlgmodule.mm" "DlgModule/MacOSX/config.cpp" -o "DlgModule (x64)/MacOSX/libdlgmod.dylib" `sdl2-config --cflags --static-libs` -I/opt/local/include -L/opt/local/lib -std=c++17 -I. -ObjC++ -framework Cocoa -shared -fPIC -arch arm64 -arch x86_64
