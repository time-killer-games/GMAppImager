# ImGuiFileDialogCLI
ImGuiFileDialogCLI

![windows.png](windows.png)

![macintosh.png](macintosh.png)

![ubuntu.png](ubuntu.png)

![freebsd.png](freebsd.png)
