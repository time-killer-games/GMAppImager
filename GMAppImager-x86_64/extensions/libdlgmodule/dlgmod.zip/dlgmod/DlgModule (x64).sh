cd "${0%/*}"

mkdir "DlgModule (x64)"
clang++ "libSDL2.a" "lib/ImGuiFileDialog/ImGuiFileDialog.cpp"  "imgui.cpp" "imgui_impl_sdlrenderer.cpp" "imgui_impl_sdl.cpp" "imgui_draw.cpp" "imgui_tables.cpp" "imgui_widgets.cpp" "dlgmodule.mm" "setpolicy.mm" "main.cpp" "config.cpp" -o "DlgModule (x64)/dlgmod" `sdl2-config --cflags --static-libs` -I/opt/local/include -L/opt/local/lib -std=c++17 -I. -ObjC++ -framework Cocoa -framework UniformTypeIdentifiers -fPIC -arch arm64 -arch x86_64
